## 隐私声明
我们重视您的隐私。该网站不存储您上传的任何内容。所有内容将被直接上传到OpenAI，OpenAI将承担所有与该内容相关的责任。该网站不对任何与上传内容有关的法律责任负责。请确保您了解[OpenAI的隐私政策](https://openai.com/privacy/)，并同意其所涵盖的内容。

## Privacy Statement
Your privacy is important to us. This site does not store any content you upload. All content will be uploaded directly to OpenAI and OpenAI will assume all responsibility in relation to that content. The site is not responsible for any legal liability related to the uploaded content. Please ensure that you understand [OpenAI's Privacy Policy](https://openai.com/privacy/) and agree to the content covered by it.